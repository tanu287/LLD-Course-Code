package models;

import java.util.Date;

public class Notification {
    private int id;
    private String notificationContent;
    private Date creationTime;

    public void sendInviteNotification() {}
    public void sendCancelNotification() {

    }

}

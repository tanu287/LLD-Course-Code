package models;

import java.util.List;

public class Calendar {
    private List<Meeting> meetings;
}

package models;

import java.util.Date;

public class Interval {
    private Date startTime;
    private Date endTime;
}

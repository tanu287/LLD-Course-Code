package models;

public class User {
    private String name;
    //TODO: write down getter and setter for all the private elements
    private String email;
    private int id;
    private Calendar userCalendar;


    public void respondToInvitation(Notification message) {}
    public void respondToMeeting() {}
    public void checkCalendar() {}

}
